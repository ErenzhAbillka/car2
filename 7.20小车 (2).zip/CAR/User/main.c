#include "stm32f10x.h"          // STM32标准库头文件
#include "Delay.h"
#include "OLED.h"
#include "Timer.h"
#include "Encoder.h"            // 左轮编码器接口头文件
#include "Encoder1.h"           // 右轮编码器接口头文件
#include "Motor.h"
#include "car.h"
#include "MPU6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "xunji.h"              // 循迹传感器相关头文件
#include "key.h"
#include "led.h"
#include "Buzzer.h"
#include "pid.h"
#include "speed_filter.h"       // 速度滤波接口
#include "HCSR04.h"       // 速度滤波接口


// 宏定义部分，根据你的硬件参数配置
#define WHEEL_CIRCUMFERENCE 0.188f  // 轮子周长，单位米，示例为直径0.06m的轮子
#define ENCODER_PPR 500             // 编码器每转脉冲数（Pulses Per Revolution）
#define SAMPLE_TIME 0.01f           // 采样时间，单位秒（对应定时器中断周期，比如10ms）

// 全局变量
int sensors1[8];                   // 传感器状态缓存数组
int stop_flag = 0;                 // 停车标志计数，用于判断是否停车
int KeyNum = 0;                   // 按键编号
int confirm = 0;                   // 驱动确认标志，1使能驱动，0禁止
int MODE = 0;                     // 工作模式变量（备用）
int num = 0;                      // 按键切换变量
int left_pwm, right_pwm;




float base_v = 53;  // 巡线基础速度（可调）
float leftSpeed = 0.0f;           // 左轮滤波后速度，单位m/s
float rightSpeed = 0.0f;          // 右轮滤波后速度，单位m/s


uint64_t numlen(uint64_t num)//计算数字的长度
{
    uint64_t len = 1;        // 初始长度为1
    for(; num > 9; ++len)    // 判断num是否大于9，否则长度+1
        num /= 10;	         // 使用除法进行运算，直到num小于1
    return len;              // 返回长度的值
}



void FollowAndTrack_Control(void)
{
    // 获取距离
    int Distance_mm = sonar_mm();
    if (Distance_mm < 50 || Distance_mm > 1000)
        Distance_mm = TARGET_DISTANCE_MM;

    // 跟车 PID
    float error = Distance_mm - TARGET_DISTANCE_MM;
    Distance_PID.integral += error;
    float derivative = error - Distance_PID.prev_error;
    float follow_adjust = Distance_PID.Kp * error +
                          Distance_PID.Ki * Distance_PID.integral +
                          Distance_PID.Kd * derivative;
    Distance_PID.prev_error = error;

    // 组合速度，限幅
    float adjusted_speed = base_v + follow_adjust;
    adjusted_speed = constrain_float(adjusted_speed, 100, MAX_PWM);

    // 巡线 PID，控制左右轮 PWM
    trait(&left_pwm, &right_pwm, (int)adjusted_speed);

    // 控制左右轮
    Motor_leftSetSpeed(right_pwm);
    Motor_rightSetSpeed(left_pwm);
}


/**
 * @brief 计算轮子的线速度
 * @param encoder_count 编码器在采样周期内的计数值（增量）
 * @return 计算出的线速度，单位米/秒(m/s)
 */
float CalculateSpeed(int16_t encoder_count)
{
    // 速度 = (脉冲数/编码器分辨率) / 采样时间 * 轮子周长
    // 计算轮子每秒转速，再换算成线速度
    return ((float)encoder_count / ENCODER_PPR) / SAMPLE_TIME * WHEEL_CIRCUMFERENCE;
}


/**
 * @brief 主程序入口
 * @note 初始化所有模块，进入死循环等待中断和处理按键等
 */
int main(void)
{
    // 初始化各硬件模块
    OLED_Init();            // OLED显示屏初始化
    Timer_Init();           // 定时器初始化（含中断配置）
    Encoder_Left_Init();    // 左轮编码器初始化
    Encoder_Right_Init();   // 右轮编码器初始化
    Motor_Init();           // 电机驱动初始化
    mpu_dmp_init();         // MPU6050传感器初始化（含DMP）
    Xunji_Init();           // 循迹传感器初始化
    Key_Init();             // 按键初始化
    LED_Init();             // 指示灯初始化
    Buzzer_Init();          // 蜂鸣器初始化
    PID_Init();             // PID控制参数初始化

    // 在OLED第一行显示固定标签
    OLED_ShowString(1, 1, "Track:");

	while (1)
	{
		
		int Distance_mm=sonar_mm();			//获取距离测量结果，单位毫米（mm）		
		int Distance_m=Distance_mm/1000;	//转换为米（m）为单位，将整数部分放入Distance_m
		int Distance_m_p=Distance_mm%1000;	//转换为米（m）为单位，将小数部分放入Distance_m_p
					
		read_sensors(sensors1);//读取传感器的值
//		update_redSensor();//更新传感器的值
	
//while里面主要写的是灰度传感器根据实际场景进行判别标志位，然后用于下面定时器的驱动以及声光报警的响应
//error为状态机（作为状态） warnflag作为开关报警报纸位，inerflag作为 下面定时器蜂鸣器流程的标志位、changeflag用于小车的运动形式

		OLED_ShowNum(1,1,Trackn,3);//模式显示
		
	 // 停车
		int stop_condition = 0;
    if (Trackn  == 0  )
		{
         stop_condition = 1;
    }
    if(stop_condition) {
        stop_flag++;
    } 
		OLED_ShowNum(1,5, stop_flag,3);//模式显示
		KeyNum = Key_GetNum();
		 if(KeyNum == 1)
		 {
			 MODE++;
			 MODE%=5;
		 }
		 if(KeyNum == 2)
		 {
			 num ++;
			 if(num>2)
			 {
				 num = 1;
			 }
		 }
		
	if(num == 1)
	{
		confirm = 1; //电机驱动标志位 1为驱动，0为暂停
		OLED_ShowString(2,1,"OK");
	}
	if(num == 2)
	{
		confirm = 0;
		OLED_ShowString(2,1,"NO");
	}
	
  }
}



void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)		//判断是否是TIM4的更新事件触发的中断
	{
		update_redSensor();//更新传感器的值
	  Key_Tick();//非阻塞式按键
		if( stop_flag <10)
		{
			FollowAndTrack_Control();		
		}else
		{
			 Motor_leftSetSpeed(0);
		   Motor_rightSetSpeed(0);
		}
			
				TIM_ClearITPendingBit(TIM4, TIM_IT_Update);			//清除TIM4更新事件的中断标志位	
	}
}

